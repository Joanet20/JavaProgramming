class SequenceTest {
   
  public static void main (String args[]) {
 
    Sequence mySequence = new Sequence();
  
  mySequence.displaySequence();

  } 
}
