class CounterTest {
   
  public static void main (String args[]) {
 
  Counter myCounter = new Counter();
  
  myCounter.displayCount();

  } 
}
