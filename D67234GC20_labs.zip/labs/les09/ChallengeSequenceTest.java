class ChallengeSequenceTest {

  public static void main (String args[]) {

    ChallengeSequence mySequence = new ChallengeSequence();

    mySequence.displaySequence();

  }
}
