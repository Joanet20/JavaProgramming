class OrderTest {
   
  public static void main (String args[]) {
 
    Order myOrder = new Order();
  
    myOrder.calculateTotal();

  } 
}
