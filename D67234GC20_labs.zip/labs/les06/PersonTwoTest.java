public class PersonTwoTest {
   
  public static void main (String args[]) {
 
    PersonTwo myPersonTwo = new PersonTwo();
  
    myPersonTwo.displayPersonInfo();

  } 
}
