package duke.item;

public class Socks extends Clothing {

    public Socks (int itemID, String description, char colorCode, double price, int quantityInStock) {
      super( itemID,  description,  colorCode, price, quantityInStock);
    }

}
