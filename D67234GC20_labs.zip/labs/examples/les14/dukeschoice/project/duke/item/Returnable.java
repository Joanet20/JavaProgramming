package duke.item;

public interface Returnable {
    public String doReturn();
}
