package duke.purchase;

public class Customer {   
}
