public class WhileRectangleTest {

   public static void main(String args[]) {
     
    WhileRectangle myWhileRectangle = new WhileRectangle();

    myWhileRectangle.displayRectangle();
     
   }
}
