public class VacationScaleTwoTest {
   
  public static void main (String args[]) {
 
    VacationScaleTwo myVacationScale = new VacationScaleTwo();
  
    myVacationScale.setVacationScale();

    myVacationScale.displayVacationDays();

  } 
}
