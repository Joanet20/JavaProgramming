/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class ShirtTest {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Shirt myShirt;
        myShirt = new Shirt();
        myShirt.displayInformation();
    }
}
